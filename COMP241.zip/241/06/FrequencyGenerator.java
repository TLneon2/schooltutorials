/**
 * COMP 241 Lab 06 2017.
 * April 9th 2017.
 */

package week06;

import java.util.*;
import java.io.*;

/** This class finds a random char.
 * based on letter frequency Returns.
 * a concatenated string of chars.
 * @author Theon.
 */
public class FrequencyGenerator implements WordGenerator {
    /** Double array of letter frequencies. */
    private double[] doublearray;
    /** Provided random object. */
    private Random random;
    /** counts lines. **/
    private int lines;
    /**
     * Scans file input and stores it in doublearray.
     * @param r Random
     */
    public FrequencyGenerator(Random r) {
        random = r;
        try {
            File input = new File("letter-frequencies.txt");
            Scanner sc = new Scanner(input);
            int length = (int) input.length();
            int index = 0;
            doublearray = new double [length];
            while (sc.hasNextDouble()) {
                doublearray[index] = sc.nextDouble();
                index++;
            }
            sc.close();
        } catch (FileNotFoundException e) {
            System.out.println("The file was not found.");
        }
    }

    /**
     * Choose int index based on frequencies
     * against random doubles.
     * @param w double array
     * @return i int
     */
    public int chooseIndex(double[] w) {
        int i = 0;
        double r = random.nextDouble();

        while (r > w[i]) {
            r = r - w[i];
            i = i + 1;
        }
        return i;
    }

    /**
     * Generates concatenated string based
     * on chosen index for n times.
     * @param n int, number of iterations.
     * @return str String.
     */
    public String nextWord(int n) {
        String str = "";

        for (int i = 0; i < n; i++) {
            char a = (char)('a' + chooseIndex(doublearray));
            str += a;
        }
        System.out.println(str);
        return str;
    }

}
