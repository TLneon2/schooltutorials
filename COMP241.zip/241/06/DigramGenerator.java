/**
 * COMP 241 Lab 06 2017.
 * April 9th 2017.
 */

package week06;

import java.util.*;
import java.io.*;

/**
 * This class generates random chars.
 * based on the length of their strings
 * and returns a concatenated string
 * @author Theon.
 */
public class DigramGenerator implements WordGenerator {

    /** Provided random object. */
    private static Random random;
    /** String str for first letters. */
    private String str;
    /** Strarray for continuations. */
    private String[] strarray;
    /** Determines array index. */
    private int charindex;
    
    /**
     *  Constructor scans through relevant files.
     *  and stores them as str and strarray
     *  @param r Random
     */
    public DigramGenerator(Random r) {
        random = r;

        try {
            File stringfile = new File("first-letters.txt");
            Scanner sinput = new Scanner(stringfile);
            File arrayfile = new File("continuations.txt");
            Scanner ainput = new Scanner(arrayfile);
            int length = (int) arrayfile.length();
            int index = 0;
            str = "";
            strarray = new String[length];

            if (sinput.hasNextLine()) {
                str = sinput.nextLine();
            }

            while (ainput.hasNextLine()) {
                strarray[index] = ainput.nextLine();
                index++;
            }
            sinput.close();
            ainput.close();

        } catch (FileNotFoundException e) {
            System.out.println("The file(s) was not found.");
        }
    }

    /**
     *  Stringbuilder appends all chars to string.
     *  Use random object to find index of char
     *  return char's position to skip to relevant
     *  array location. Generate another random
     *  char at array index, and skip to another
     *  array index based on that char. Continue
     *  for n times.
     *  @param n int, number of iterations
     *  @return rstr, a concatenated string
     */
    public String nextWord(int n) {

        String rstr = "";
        StringBuilder sb = new StringBuilder();

        int index = random.nextInt(str.length());
        char firstletter = str.charAt(index);
        sb.append(firstletter);
        charindex = firstletter - 'a';

        if (n > 2) {
            for (int i = 0; i < n - 1; i++) {
                int subindex = random.nextInt(strarray[charindex].length());
                char subchar = strarray[charindex].charAt(subindex);
                sb.append(subchar);
                charindex = subchar - 'a';
            }
        } else {
            System.out.println("error"); 
        }

        rstr = sb.toString();

        return rstr;
    }

}
