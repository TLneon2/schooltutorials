package week06;

public interface WordGenerator {

    String nextWord(int length);

}
