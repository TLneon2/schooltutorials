package week05;

public class RecursiveApp{
    private static long q;

    public static long digits(long n) {
        q = n / 10;
        if (q == 0) {
            return 1;
        } else {
            return digits(q) + 1;
        }
    }

    public static long sumOfDigits(long n) {
        if (n >= 0) {
            q = n / 10;
            if (q == 0) {
                return n % 10;
            } else {
                return sumOfDigits(q) + n % 10;
            }
        } else {
            n = -n;
            q = n / 10;
            if (q == 0) {
                return n % 10;
            } else {
                return -(sumOfDigits(q) + n % 10);
            }            
        }
    }

}
