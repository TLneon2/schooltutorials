package week05;

public class Coins{

    public static final boolean HEADS = true;
    public static final boolean TAILS = false;
	
    private boolean[] coins;
	
    public Coins(boolean[] coins) {
        this.coins = coins;
    }

    public int countHeads() {
        int counter = 0;
        for (int i = 0; i < coins.length; i ++) {
            if (coins[i]) {
                counter++;
            }
        }
        return counter;
    }

    public String toString() {
        String str = "";
        for (int i = 0; i < coins.length; i++) {
            if (coins[i] == HEADS) {
                str += "H";                
            }
            else {
                str += "T";
            }
        }
        return str;
    }

    public Coins(String c) {
        char[] ac = c.toCharArray();
        this.coins = new boolean [ac.length];
        int i = 0;

        for (char a: ac) {
            if (a == 'H') {
                coins[i] = true;
            }
            else {
                coins[i] = false;
            }
            i++;
        }
    }

    public Coins(int length) {
        this.coins = new boolean [length];
        for (int i = 0; i < coins.length; i++) {
            if (Math.random() > 0.5) {
                coins[i] = true;
            }
            else {
                coins[i] = false;
            }
        }
    }

    public int countRuns() {
        int runs = 0;

        for (int i = 0; i < coins.length - 1; i ++) {
            if (coins[i] && !(coins[i+1])) {
                runs++;
            }
            else if (!(coins[i]) && coins[i+1]) {
                runs++;
            }
        }
        return runs + 1;
    }
		
}
