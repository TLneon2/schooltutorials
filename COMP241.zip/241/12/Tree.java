package week12;

import java.util.*;

/**
 * Skeleton of the recursive implementation of a general tree.
 * 
 * @author Michael Albert
 * @param <T> The type of values stored in the tree.
 */
public class Tree<T> {
    
    private T rootValue;
    private List<Tree<T>> children;
    
    public Tree(T rootValue, List<Tree<T>> children) {
        this.rootValue = rootValue;
        this.children = children;
    }

    public Tree(T rootValue) {
        this(rootValue, new ArrayList<Tree<T>>());
    }
    
    public int size() {
        if (rootValue == null) {
            return 0;
        }
        int counter = 1;
        for (Tree<T> child: children) {
            if (child != null) {
                counter += child.size();
            }
        }
        return counter;
    }
    
    public int maxDegree() {
        if (rootValue == null) {
            return 0;
        }
        int counter = children.size();
        for (Tree<T> child: children) {
            if (child != null) {
                counter = Math.max(counter, child.maxDegree());
            }
        }
        return counter;        

    }
    
    public void add(Tree<T> child) {
        children.add(child);
    }

    public Tree<T> find(T value) {
        if (rootValue.equals(value)) {
            return this;
        }
        for (Tree<T> child : children) {
            Tree<T> match = child.find(value);
            if (match != null) {
                return match;
            }
        }
        return null;
    }
    
    public List<T> postOrder() {
        if (children.isEmpty()) {
            ArrayList<T> a = new ArrayList<T>();
            a.add(rootValue);
            return a;
        }
        else {
            ArrayList<T> a = new ArrayList<T>();
            for (Tree<T> child: children) {
                a.addAll(child.postOrder());
            }
            a.add(rootValue);
            return a;
        }
    }
    
    public String toString() {
        if (children.isEmpty()) {
            return rootValue.toString();
        }
        return rootValue.toString() + ' ' + children.toString();
    }

    public String toIndentedString() {
        return toIndentedString2() + '\n';

    }
    
    public String toIndentedString2() {
        StringBuilder sb = new StringBuilder(rootValue.toString());
        for (Tree<T> child: children) {
            sb.append('\n');
            sb.append(child.toIndentedString2().replaceAll("(?m)^", "  "));
        }
        return sb.toString();
    }

    /** A helper method for testing (used by main).  Searches tree for
     *  the given target and adds white space separated children to
     *  the tree matching target if there is one.
     *
     * @param target the root value to seach for.
     * @param children a white space separated list of children to add
     * to the tree whose value matches target.
     */
    private static void addChildren(String target, String children) {
        Tree<String> parent = tree.find(target);
        if (parent != null) {
            for (String child : children.split(" ")) {
                parent.add(new Tree<>(child));
            }
        }
    }

    /** A tree instance used for testing. */
    private static Tree<String> tree;

    /**
     * Entry point of the program (used for testing).
     *
     * @param args command line arguments are not used.
     */
    public static void main(String[] args) {
        System.out.println("Creating tree\n-------------");
        tree = new Tree<>("food");
        System.out.print(tree + "\nsize: " + tree.size());
        System.out.println(", max degree: " + tree.maxDegree());
        System.out.println("\nAdding children\n----------------");
        addChildren("food", "meat fruit vegetable");
        System.out.print(tree + "\nsize: " + tree.size());
        System.out.println(", max degree: " + tree.maxDegree());
        System.out.println("\nAdding deeper children\n----------------------");
        addChildren("meat", "chicken beef fish");
        addChildren("fish", "salmon cod tuna shark");
        addChildren("vegetable", "cabbage");
        System.out.print(tree + "\nsize: " + tree.size());
        System.out.println(", max degree: " + tree.maxDegree());
        System.out.println("\nPostorder\n---------");
        System.out.println(tree.postOrder());
        System.out.println("\nIndented string\n---------------");
        System.out.print(tree.toIndentedString());
    }

}
