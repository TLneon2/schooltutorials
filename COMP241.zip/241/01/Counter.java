/**
 * 
 * Lab 01 COMP241 2017
 * March 3rd 2017
 */

package week01;

import java.util.*;

/** 
 * This class only contains one main method.
 * @author Theon.
 */

public class Counter {
    /** 
     * Main method to read input from System.in and count lines and words.
     * @param args program arguments
     */
    public static void main(String[] args) {
        int lines = 0;
        int words = 0;
        String input = null;
        int i;

        Scanner s = new Scanner(System.in);

        while (s.hasNextLine()) {
            lines++;
            input = s.nextLine();
            if (input.trim().length() > 0) {
                words++;

                for (i = 0; i < input.length(); i++) {
                    if (input.charAt(i) == ' ') {
                        words++;
                    }
                }
            }

        }

        System.out.println("lines: " + lines);
        System.out.println("words: " + words);

        s.close();
    }
}
