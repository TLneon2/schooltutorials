/**
 * COMP 241 Lab 10 2017.
 * 14th May 2017.
 */
package week10;

import java.util.*;
/** An implementation of non-binary Tree using mainly recursion.
 *
 * @author theonlw
 *
 */
public class Tree<T> {
    /** The smallest value (or root) of this Tree. */
    private T rootValue;
    /** An arraylist of children values. */
    private List<Tree<T>> children;

    /** Sets the given parameters to root and children.
     * @param rootValue the root of the tree
     * @param children List<Tree<T>>
     */
    public Tree(T rootValue, List<Tree<T>> children) {
        this.rootValue = rootValue;
        this.children = children;
    }
    /** Creates a new Tree with rootValue.
     * @param rootValue T type
     */
    public Tree(T rootValue) {
        this(rootValue, new ArrayList<Tree<T>>());
    }
    /**
     * Recursively count size of each child in.
     * arraylist children then increment
     * @return counter, int
     */
    public int size() {
        if(rootValue == null) {
            return 0;
        }
        int counter = 1;
        for (Tree<T> child: children) {
            if (child != null) {
                counter += child.size();
                //System.out.println(child.size());
            }
        }
        return counter;
    }
    /**
     * Compares and returns greater value.
     * between arraylist size and the
     * max degree of the subtree child.
     * @return counter, int
     */    
    public int maxDegree() {
        if(rootValue == null) {
            return 0;
        }
        int counter = children.size();
        for (Tree<T> child: children) {
            if (child != null) {
                counter = Math.max(counter, child.maxDegree());
            }
        }
        return counter;
    }
    /**
     * Adds children.
     * @param child some text
     */     
    public void add(Tree<T> child) {
        children.add(child);
    }
    /**
     * Finds value in tree.
     * @param value T type
     * @return match Tree<T>
     */   
    public Tree<T> find(T value) {
        if (rootValue.equals(value)) {
            return this;
        }
        for (Tree<T> child : children) {
            Tree<T> match = child.find(value);
            if (match != null) {
                return match;
            }
        }
        return null;
    }
    /**
     * Visit all the children before.
     * the root. If empty, add root and return.
     * Otherwise, add children then add root and
     * return.
     * @return a, arraylist
     */     
    public List<T> postOrder() {
        if (children.isEmpty()) {
            ArrayList<T> a = new ArrayList<T>();
            a.add(rootValue);
            return a;
        } else {
            ArrayList<T> a = new ArrayList<T>();
            for (Tree<T> child : children) {
                a.addAll(child.postOrder());
            }
            a.add(rootValue);
            return a;
        }        
    }
    /**
     * To String default method.
     * @return String
     */    
    public String toString() {
        if (children.isEmpty()) {
            return rootValue.toString();
        }
        return rootValue.toString() + ' ' + children.toString();
    }

    /**
     * Creates a stringbuffer to store indented strings.
     * @return buf.toString
     */       
    public String toIndentedString() {
        StringBuffer buf = new StringBuffer();
        this.toIndentedString2(buf, 0);
        return buf.toString();
    }
    /**
     * Decides on the correct indentation for each child.
     * @param buf Stringbuffer
     * @param indentationLevel int
     */
    private void toIndentedString2(StringBuffer buf, int indentationLevel) {
        for (int i = 0; i < indentationLevel; i++) {
            buf.append("  ");
        }
        //conditional operator decides which value to append based on expression
        buf.append(rootValue != null ? rootValue.toString() : "null");
        buf.append('\n');
        // Recurse over the children, building deeper indentation
        for (Tree<T> child : children) {
            child.toIndentedString2(buf, indentationLevel+1);
        }
    }
    /** A helper method for testing (used by main).  Searches tree for.
     *  the given target and adds white space separated children to
     *  the tree matching target if there is one.
     *
     * @param target the root value to seach for.
     * @param children a white space separated list of children to add
     * to the tree whose value matches target.
     */
    private static void addChildren(String target, String children) {
        Tree<String> parent = tree.find(target);
        if (parent != null) {
            for (String child : children.split(" ")) {
                parent.add(new Tree<>(child));
            }
        }
    }
    /** A tree instance used for testing. */
    private static Tree<String> tree;

    /**
     * Entry point of the program (used for testing).
     *
     * @param args command line arguments are not used.
     */
    public static void main(String[] args) {
        System.out.println("Creating tree\n-------------");
        tree = new Tree<>("food");
        System.out.print(tree + "\nsize: " + tree.size());
        System.out.println(", max degree: " + tree.maxDegree());
        System.out.println("\nAdding children\n----------------");
        addChildren("food", "meat fruit vegetable");
        System.out.print(tree + "\nsize: " + tree.size());
        System.out.println(", max degree: " + tree.maxDegree());
        System.out.println("\nAdding deeper children\n----------------------");
        addChildren("meat", "chicken beef fish");
        addChildren("fish", "salmon cod tuna shark");
        addChildren("vegetable", "cabbage");
        System.out.print(tree + "\nsize: " + tree.size());
        System.out.println(", max degree: " + tree.maxDegree());
        System.out.println("\nPostorder\n---------");
        System.out.println(tree.postOrder());
        System.out.println("\nIndented string\n---------------");
        System.out.print(tree.toIndentedString());
    }

}

