package week09;
/**
 * Block Exception creates runtime exceptions if called.
 *
 * @author Wilson Law, Theon Leong, Marcus Lee
 */
public class BlockException extends RuntimeException{
    /** requirement for custom exceptions. */
    private static final long serialVersionUID = 7526471155622776147L;
    /**
     * Block exception returns message.
     * @param message returns messages.
     */    
    public BlockException(String message) {
        super(message); 
    }
}
