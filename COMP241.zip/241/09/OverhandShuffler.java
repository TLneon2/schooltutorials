package week09;

import java.util.Arrays;
import java.util.*;
import java.util.Random;
/**
 * An overhand shuffler that implements an interface and returns
 * various methods.
 * @author Theon Leong, Marcus Lee, Wilson Low
 */
public class OverhandShuffler implements Overhand{
    /** int array to hold cards to be manipulated. */
    protected int[] deck;
    /** int array to hold cards to be compared to. */
    protected int[] deckcopy;
    /** temporary int array used in the shuffle method. */
    public int[] replica;
    /** int counter for block[i]. */
    protected int i = 0;
    /** modifier to copy replica to deck. *///
    public int replicaindex;
    /** int to store the number of shuffles. *///
    public int count = 0;
    /** int to store the number of times order cycles. */
    protected int cycles = 0;
    /** int array to store the block sizes for shuffle and order. */
    protected int[] blocks;
    /** int array t store the block sizes for randomShuffle. */
    protected int[] blocksrandom;
    /** int to store the randomly generated deck for randomShuffle. */
    protected int[] randomDeck;
    /** int to store cumulative countShuffles. */
    protected int sum;
    /** int constant to store break probability.  */
    private static final double CONSTANT = 0.1;
    
    /**
     * Makes a new deck consisting of size cards numbered from 0 up
     * to size-1 from top to bottom.
     *
     * @param size int size of the deck.
     */
    public void makeNew(int size) {
        deck = new int [size];
        int index = 0;
        for(int i = 0; i < size; i++) {
            deck[i] = index;
            //System.out.print(index + " ");
            index++;
        }
        deckcopy = Arrays.copyOf(deck, deck.length);
        replica = new int [deck.length];
        replicaindex = deck.length - 1;
    }
    /**
     * Returns the current state of the deck as an int[].
     *
     * @return an int array of the current state of the deck.
     */
    public int[] getCurrent(){

        if(deck == null){
            deck = new int[0];
            return deck;
        }
        return deck;
    }
    /**
     * Shuffles the current state of the deck according
     * to the array of block sizes given.
     *
     * @param blocks int array of block sizes.
     */
    public void shuffle(int[] blocks) {
        //get the size of the block
        int iterations = blocks.length - 1;
        int blockvalue = blocks[i];
        for(int j = blockvalue-1; j >= 0; j--) { //number of values to copy
            replica[replicaindex] = deck[j + count]; //actual swap
            replicaindex--;
        }
        count += blockvalue; //modifier for future iterations
        //run for n times
        if (i < iterations) {
            i++;
            shuffle(blocks);
        }
        deck = Arrays.copyOf(replica, replica.length); 
        count = 0;
        i = 0;
        replicaindex = deck.length - 1;
    }
    /**
     * Returns the minimum number of times that the deck could be shuffled
     * (from its initial state) using the same set of block sizes each time
     * (as given by its argument) in order to return the deck to its
     * initial state.
     *
     * @param blocks int array of block sizes.
     * @return an int of the minimum number of times that the deck could
     * be shuffled to get back to its original state.
     */
    public int order (int[] blocks){
        int cycles = 0;
        deckcopy = Arrays.copyOf(deck, deck.length);
        shuffle(blocks);
        cycles++;
        for(int i = 0; i < deck.length; i++){                
            while(deck[i] != deckcopy[i]) {
                shuffle(blocks);
                cycles++;
            }
        }
        return cycles;
    }
    /**
     * Returns the number of pairs of cards which were consecutive in
     * the original deck, and are still consecutive (and in the same order)
     * in the current state of the deck.
     *
     * @return an int of the number of pairs consecutive in the original
     * and current deck.
     */
    public int unbrokenPairs(){
        int counter = 0;
        for(int i = 0; i < deck.length - 1; i++) {
            if (deck[i]+1 == deck[i+1]) {
                counter++;
            }
        }
        return counter;
    }
    /**
     * Experiment testing 4 shuffles with varying block length
     * to identify possible patterns and print a short report.
     */
    public void tryRepeat() {
        /* Experiment Details:
        int[] a1 = {2,3,0};
        int[] a2 = {3,1,1};
        int[] a3 = {2,1,2};
        int[] a4 = {1,1,3};
        shuffle(a1);
        getCurrent();
        shuffle(a2);
        getCurrent();
        shuffle(a3);
        getCurrent();
        shuffle(a4);
        getCurrent();
        shuffle(a1);
        getCurrent();
        shuffle(a2);
        getCurrent();
        shuffle(a3);
        getCurrent();
        shuffle(a4);
        getCurrent();
        */
        System.out.println("Experimenting with a sequence of five cards,");
        System.out.println("there is no noticeable pattern");
        System.out.println("even if the same sequence of shuffles is used.");
        System.out.println("Any pattern seen is merely coincidence");
        System.out.println("rather than any trend that is consistent");
        System.out.println("if the numbers or block sequences were changed.");
    }
    /**
     * Perform a random overhand shuffle using a break probability of 0.1.
     */
    public void randomShuffle() {
        Random r = new Random();
        int mod = 0;
        int blocksizes = 1;
        blocksrandom = new int[deck.length];
        blocksrandom[0] = 1;
        for(int a = 0; a < deck.length-1;a++){
            double i = r.nextDouble();
            if(i >= CONSTANT) {
                blocksizes++; //calculate block sizes with random
            }
            if(i <= CONSTANT) {
                blocksizes = 1; // you must at least have one card in the deck
                mod++; // exit condition
            }
            blocksrandom[0 + mod]= blocksizes;
        } 
        shuffle(blocksrandom);
    }
    /**
     * Creates a randomly generated deck with no duplicates from 0 to 49.
     *
     * @param size the size of the randomly generated deck.
     */
    public void deckRandom(int size) {
        ArrayList < Integer > duplicates = new ArrayList < Integer > ();
        randomDeck = new int[size - 1];
        Random r = new Random();
        for (int i = 0; i < size - 1; i++) {
            int rand = r.nextInt(size);
            randomDeck[i] = rand;
            while (duplicates.contains(rand)) {
                rand = r.nextInt(size);
                randomDeck[i] = rand;                
            }
            duplicates.add(rand);
        }
        deck = Arrays.copyOf(randomDeck, randomDeck.length);
    }

    /**
     * Return how many random shuffles need to be done before the number of
     * unbroken pairs is less than the given parameter.
     *
     * @param unbrokenPairs the number of unbroken pairs must be less than of.
     * @return an int of how many random shuffles need to be done within the
     * threshold.
     */
    public int countShuffle(int unbrokenPairs) {
        int newPairs = unbrokenPairs();

        int count = 0;
        while (newPairs > unbrokenPairs) {
            randomShuffle();
            count++;
            newPairs = unbrokenPairs();
        }
        sum += count;
        return count;
    }
    /**
     * Load the deck using the given numbers.
     *
     * @param cards an int array of the new deck of cards.
     */
    public void load(int[] cards) {
        deck = new int [cards.length];
        for(int i = 0; i < cards.length; i++) {
            deck[i] = cards[i];
        }
        deckcopy = Arrays.copyOf(deck, deck.length);
        replica = new int [deck.length];
        replicaindex = deck.length - 1;
    }
}
