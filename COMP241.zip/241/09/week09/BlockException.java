package week09;

public class BlockException extends RuntimeException{
    private static final long serialVersionUID = 7526471155622776147L;
    public BlockException(String message) {
        super(message); 
    }
}
