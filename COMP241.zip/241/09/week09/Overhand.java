package week09;
public interface Overhand {
	public void makeNew(int size);
	public int[] getCurrent();
	public void shuffle(int[] blocks) throws BlockException;
	public int order(int[] blocks);
	public int unbrokenPairs();
	public void tryRepeat();
	public void randomShuffle();
	public int countShuffle(int unbrokenPairs);
	public void load(int[] cards);
	public void deckRandom(int size);
}
