package week09;

import java.util.Arrays;
import java.util.*;
import java.util.Random;
/*
 * @authors Theon Leong, Marcus Lee, Wilson Low
 * An overhand shuffler.
 */
public class OverhandShuffler implements Overhand{
	public int[] deck = {};
	protected int[] deckcopy;
	public int[] replica;
	protected int i = 0;
	public int replicaindex;
	public int count = 0;
	protected int cycles = 0;
	protected int[] blocks;
	protected int[] blocksrandom;
	protected int[] randomDeck;
	protected int sum;
	/*
	 * 
	 * 
	 */
	public void makeNew(int size) {
		deck = new int [size];
		int index = 0;
		for(int i = 0; i < size; i++) {
			deck[i] = index;
			System.out.print(index + " ");
			index++;
		}
		deckcopy = Arrays.copyOf(deck, deck.length);

		replica = new int [deck.length];
		replicaindex = deck.length - 1;
		System.out.println("& Replica index is: " + replicaindex);
	}
	/*
	 * 
	 * 
	 */
	
	public int[] getCurrent(){
		String array = Arrays.toString(deck);
		System.out.println(array);
		return deck;
	}
	
	/*
	 * 
	 * 
	 */
	public void shuffle(int[] blocks) //throws BlockException 
		{
		//get the size of the block
		int iterations = blocks.length - 1;
		int blockvalue = blocks[i];
		System.out.println("Each block value is: " + blockvalue);
		for(int i = 0; i<blocks.length; i++){
			if (blocks[i] < 0){
				throw new BlockException("Negative block size !");
			}
		}
		//System.out.println("The modifier for copying is: " + count);
		
		for(int j = blockvalue-1; j >= 0; j--) { //number of values to copy
			replica[replicaindex] = deck[j + count]; //actual swap
			replicaindex--;
		}
		
		String array = Arrays.toString(replica);
		System.out.println(array);

		count += blockvalue; //modifier for future iterations
		//run for n times
		if (i < iterations) {
		i++;
		shuffle(blocks);
		}
		
		deck = Arrays.copyOf(replica, replica.length); //after deck is finished copying must reset all parameters
		count = 0;
		i = 0;
		replicaindex = deck.length - 1;
	}
	
	/*
	 * 
	 * 
	 */
	public int order (int[] blocks){
		boolean exit = false;
		replica = new int [deck.length];
		
		/*
		if (Arrays.comparesTo(deck, deckcopy)) {
			return cycles;
		}
		else {
			cycles++;
			shuffle(blocks);
			return order(blocks);
		}
		*/
		//needs to run at least one prelim shuffle

		for(int i = 0; i < deck.length; i++){
			  if(deck[i] == deckcopy[i]) {
				  exit = true;
			  } else {
					shuffle(blocks);
					cycles++;
			  }
			}
		
		if (exit) {
			System.out.println("FINAL EXIT: " + cycles);
			return cycles;
		}
		
		shuffle(blocks);
		cycles++;
		System.out.println("NOTICE ME HUMAN: " + cycles);
		return order(blocks);
	}
	/*
	 * 
	 * 
	 */
	public int unbrokenPairs(){
		int counter = 0;
		for(int i = 0; i < deck.length - 1; i++) {
			if (deck[i]+1 == deck[i+1]) {
				counter++;
			}
		}
		//System.out.println(counter);
		return counter;
		}
	
	public void tryRepeat() {
		int[] a1 = {2,3,0};
		int[] a2 = {3,1,1};
		int[] a3 = {2,1,2};
		int[] a4 = {1,1,3};
		shuffle(a1);
		getCurrent();
		shuffle(a2);
		getCurrent();
		shuffle(a3);
		getCurrent();
		shuffle(a4);
		getCurrent();
		shuffle(a1);
		getCurrent();
		shuffle(a2);
		getCurrent();
		shuffle(a3);
		getCurrent();
		shuffle(a4);
		getCurrent();
		System.out.println("Experimenting with a sequence of five cards, there is no noticeable pattern even if the same sequence of shuffles is used. Any pattern seen is merely coincidence"
				+ " rather than any recurring trend that is consistent if the number of blocks or shuffles were changed.");
	}
	
	public void randomShuffle() {
		Random r = new Random();
		int mod = 0;
		int blocksizes = 1;
		blocksrandom = new int[deck.length];
		blocksrandom[0] = 1;
		for(int a = 0; a < deck.length - 1; a++) {		 
			double i = r.nextDouble();
			//System.out.println(i);
			
			if(i >= 0.1) {
				blocksizes++; //calculate block sizes with random
			}
			if(i <= 0.1) {
				blocksizes = 1; // you must at least have one card in the deck
				mod++; // exit condition
			}
			blocksrandom[0 + mod]= blocksizes;
		}		
		//String array = Arrays.toString(blocks);
		//System.out.println("RANDOM BLOCKS STUFF: " + array);
		shuffle(blocksrandom);
	}
	
	/*
	 * 
	 * 
	 */
	
	public void deckRandom(int size) {
        ArrayList < Integer > duplicates = new ArrayList < Integer > ();
		randomDeck = new int[size - 1];
		Random r = new Random();
		for (int i = 0; i < size - 1; i++) {
			int rand = r.nextInt(size) + 1;			
			randomDeck[i] = rand;
			while (duplicates.contains(rand)) {
				rand = r.nextInt(size) + 1;			
				randomDeck[i] = rand;                
            }
			duplicates.add(rand);
		}
		//String array = Arrays.toString(randomDeck);
		//System.out.println(array);
		deck = Arrays.copyOf(randomDeck, randomDeck.length);
		//unbrokenPairs();
	}

	
	public int countShuffle(int unbrokenPairs) {
		int newPairs = unbrokenPairs();
		//System.out.println("Original number of unbrokenPairs " + unbrokenPairs);
		int count = 0;
		while (newPairs > unbrokenPairs) {
		randomShuffle();
		count++;
		newPairs = unbrokenPairs();
		//System.out.println("We are counting newPairs: " + newPairs + " " + count);
		}
		sum += count;
		System.out.println("Exit & Count & Sum: " + newPairs + " " + count + " " + sum);
		return count;
	}
	
	public void load(int[] cards) {
		deck = new int [cards.length];
		for(int i = 0; i < deck.length; i++) {
			deck[i] = cards[i];
		}
	}
}
