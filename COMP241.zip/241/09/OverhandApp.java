package week09;

import java.util.*;
import java.util.stream.*;

/**
 * Main method that returns various methods and scans
 * various commands using getNums.
 *
 * @author Wilson Law, Theon Leong, Marcus Lee
 */
public class OverhandApp {
    /** overhandshuffler object a. */
    private static OverhandShuffler a = new OverhandShuffler();
    /** size of the deck. */
    private static int size = 0;
    /** condition switch to turn off exception checker. */
    private static boolean condition = true;
    /** large array size. */
    private static final int LARGE = 100;
    /**
     * The main method to return various outputs.
     *
     * @param args command line arguments are not used.
     */
    public static void main(String[] args) {
        StringBuilder s = new StringBuilder();
        Scanner input = new Scanner(System.in);
        while (input.hasNextLine()) {
            handleLine(s, input.nextLine());
        }
        input.close();
    }
    /**
     * getNums throws a block exception if blocks are negative or it's
     * sum is not equals to deck size.
     *
     * @param input a Scanner to scan inputs
     *
     * @return nums a int[] of checked input parameters
     */
    private static int[] getNums(Scanner input) {
        List<Integer> numlist = new ArrayList<Integer>();
        while (input.hasNextInt()) { 
            numlist.add(input.nextInt());            
        }
        int[] nums = new int[numlist.size()];
        for (int i = 0; i < nums.length; i++) {
            nums[i] = numlist.get(i);              
        }
        if (condition) {
            int sum = IntStream.of(nums).sum();
            for(int i = 0; i< nums.length; i++){
                if(nums[i] < 0){
                    throw new BlockException("Negative Block Size!");
                }
            }
            if(sum != size){
                System.out.println(Arrays.toString(nums));
                throw new BlockException("Sum of block != deck"); 
            }
        }       
        return nums;
    }
    /**
     * Determines various commands and returns the appropriate answers.
     *
     * @param str which are used to handle inputs
     * @param input which are used to handle inputs
     *
     */
    public static void handleLine(StringBuilder str, String input) {
        Scanner scan = new Scanner(input);
        if (scan.hasNext()) {
            String command = scan.next();
            
            switch (command) {
                case "make-new": case "m": //
                    size = scan.nextInt();
                    a.makeNew(size);
                    //a.getCurrent();
                    break;
                case "print": case "p"://
                    System.out.println(Arrays.toString(a.getCurrent()));
                    break;
                case "shuffle": case "s": //
                    //blocks = new int [getNums(scan).length];
                    int[] num1 = new int[LARGE];
                    num1 = getNums(scan);
                    a.shuffle(num1);
                    //if (scan.hasNextInt()) {
                    //str.setLength(scan.nextInt());
                    //}
                    break;
                case "order":  case "o":
                    int[] num2 = new int[LARGE];
                    num2 = getNums(scan);
                    System.out.println(a.order(num2));
                    break;
                case "unbroken-pairs": case "u": // 
                    System.out.println(a.unbrokenPairs());
                    break;
                case "random-shuffle": case "r": //
                    a.randomShuffle();
                    break;                                       
                case "count-shuffles": case "c"://
                    int unbrokenPairs = scan.nextInt();
                    a.countShuffle(unbrokenPairs);
                    break;
                case "load": case "l": //
                    int[] num3 = new int[LARGE];
                    condition = false;
                    num3 = getNums(scan);
                    a.load(num3);
                    break;
            }
        }
    }
}
