/**
 * COMP 241 Lab 03 2017.
 * March 19th 2017.
 */

package week03;

/**
 * This class creates a recursive data 
 * structure of tower and returns
 * the height of the tower as well as 
 * the number of occurances of
 * a specified character.
 * @author Theon.
 */

public class Tower {

    /** The top block. */
    private char top;

    /** The rest of the tower. */
    private Tower rest;

    /**
     * Creates a new empty Tower.
     */
    public Tower() {
        this.top = ' ';
        this.rest = null;
    }

    /**
     *  External classes can only create empty 
     *  towers and manipulate them using public 
     *  methods, because this constructor is
     *  private.
     *  @param top the top block in this tower
     *  @param rest the rest of the tower
     */
    private Tower(char top, Tower rest) {
        this.top = top;
        this.rest = rest;
    }

    /**
     *  Returns true if this tower is empty, otherwise false.  Empty
     *  towers are represented with the top block being a space
     *  character.
     * @return whether the tower is empty or not.
     */
    public boolean isEmpty() {
        return top == ' ';
    }

    /**
     *  Creates a new tower by adding the given block to the top of
     *  this tower.
     * @param block a block to add to the top of this tower.
     * @return a new tower created by adding a block to the top of
     * this tower.
     */
    public Tower add(char block) {
        return new Tower(block, this);
    }

    /**
     * Main method that runs various functions. 
     * It creates a recursive data structure of towers.
     * Tower e consists of all the previous towers and 
     * their associated char block.
     * @param args program arguements
     */

    public static void main(String[] args) {
        Tower a = new Tower();
        Tower b = new Tower('a', a);
        Tower c = new Tower('a', b);
        Tower d = new Tower('a', c);
        Tower e = new Tower('b', d);

        System.out.println(d.height());
        System.out.println(e.count('a'));
    }
        /**
         * Returns the number of tower objects within 
         * the specified tower. Calling rest.height() is the
         * same as calling c.height() and subsequently 
         * b.height() and a.height(). Recursion stops when
         * tower top is equal to nothing.
         * @return int height of the tower
         */

    public int height() {
        if (top == ' ') {
            return 0;
        } else {
            return rest.height() + 1;
        }
    }

    /**
     * Returns the number of occurances of a specified 
     * character within a tower. Check if the char can exist.
     * If top equals to nothing, tower is empty, char cannot 
     * exist and should return 0 occurances. Otherwise,
     * check if top is equal to c. If yes, add one and run 
     * count again for the bottom tower object. If no, still
     * run count again for the bottom tower object. Recursion 
     * stops when tower top is equal to nothing.
     * @param c char
     * @return int of character c
     */

    public int count(char c) {
        if (top == ' ') { // one problem solved
            return 0;
        } else if (top == c) {
            return rest.count(c) + 1;
        } else {
            return rest.count(c);
        }
    }
}
