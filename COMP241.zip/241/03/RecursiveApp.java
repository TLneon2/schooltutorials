/**
 * COMP 241 Lab 03 2017.
 * March 19th 2017.
 */

package week03;

/**
 * This class creates arrays of coins of length specified with various.
 * constructors and randomizes a heads or tails value.
 * @author Theon.
 */

public class RecursiveApp {
    /** The quotient. */
    private static long q;

    /**
     * Divides the number by 10 until it becomes zero. 
     * If not equal to zero, run again and add one.
     * @param n long values
     * @return long digits
     */
    public static long digits(long n) {
        q = n / 10;
        if (q == 0) {
            return 1;
        }
        return digits(q) + 1;
    }
    /**
     * Use previous method to count all digits
     * If number is +ve and not equal to zero, 
     * modulus it to get the remainder and add it, 
     * then run sumOfDigits again. 
     * Otherwise, return the remainder.
     * If the number is -ve, absolute the value &      
     * add the minus sign after calculation.
     * 
     * @param n long values
     * @return long sumOfDigits
     */
    public static long sumOfDigits(long n) {
        if (n >= 0) {
            q = n / 10;
            if (q == 0) {
                return n % 10;
            }
            return sumOfDigits(q) + (n % 10);
        } else {
            n = -n;
            q = n / 10;
            if (q == 0) {
                return n % 10;
            } else {
                return -(sumOfDigits(q) + (n % 10));
            }
        }
    }
        /**
         * Main method that runs various functions. It prints out number
         * of digits in a long value and tests out both the negative and    
         * positive versions of sumOfDigits.
         * 
         * @param args program arguements
         */
    public static void main(String[] args) {
        System.out.println(digits(1));
        System.out.println(sumOfDigits(10));
    }

}
