/**
 * COMP 241 Lab 04 2017.
 * March 26th 2017.
 */

package week04;

import java.util.*;

/**
 * This class checks if a 2D array is
 * a Young's Tableau with various checking
 * functions.
 * @author Theon.
 */
public class TableauApp {

    /**
     * The main method is just used for testing.
     *
     * @param args command line arguments are not used.
     */
    public static void main(String[] args) {
        final int[][] valid = {{1, 4, 5, 10, 11}, {2, 6, 8}, {3, 9, 12}, {7}};
        System.out.println(TableauApp.rowLengthsDecrease(valid));
        System.out.println(TableauApp.rowValuesIncrease(valid));
        System.out.println(TableauApp.columnValuesIncrease(valid));
        System.out.println(TableauApp.isSetOf1toN(valid));
        System.out.println(TableauApp.isTableau(valid));
    }

    /**
     * Determines whether the array passed to it is a valid tableau or not.
     *
     * @param t a two-dimensional array to test for tableau-ness.
     *
     * @return true if the parameter is a valid tableau, otherwise false
     */
    public static boolean isTableau(int[][] t) {
        if (TableauApp.rowLengthsDecrease(t) &&
            TableauApp.rowValuesIncrease(t) &&
            TableauApp.columnValuesIncrease(t) &&
            TableauApp.isSetOf1toN(t)
        ) {
            return true;
        }
        return false;
    }

    /**
     *  Returns a string representation of an array based tableau.
     *
     * @param t a two-dimensional array which represents a tableau.
     *
     * @return a string representation of an array based tableau.
     */
    public static String toString(int[][] t) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < t.length; i++) {
            for (int j = 0; j < t[i].length; j++) {
                result.append(String.format("%-4s", t[i][j]));
            }
            if (i < t.length - 1) {
                result.append("\n");
            }
        }
        return result.toString();
    }

    /**
     * Checks if preceding rows are longer than the first row.
     *
     * @param t a two-dimensional array which represents a tableau.
     *
     * @return a boolean true or false.
     */

    public static boolean rowLengthsDecrease(int[][] t) {
        if (t.length == 0) {
            return true;
        }

        for (int i = 0; i < t.length - 1; i++) {
            if (t[i].length < t[i + 1].length) {
                return false;
            }
        }
        return true;
    }

    /**
     * Checks if row values increase further down a row.
     *
     * @param t a two-dimensional array which represents a tableau.
     *
     * @return a boolean true or false.
     */

    //part two for loops (inner for)
    //t.length = 0; return true
    //[i][j] < [i][j+1] //return false
    //else return true

    public static boolean rowValuesIncrease(int[][] t) {
        if (t.length == 0) {
            return true;
        }

        for (int i = 0; i < t.length; i++) {
            for (int j = 0; j < t[i].length - 1; j++) {
                if (t[i][j] > t[i][j + 1]) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Checks if column values decrease when going up a row from
     * the bottom row.
     *
     * @param t a two-dimensional array which represents a tableau.
     *
     * @return a boolean true or false.
     */

    public static boolean columnValuesIncrease(int[][] t) {

        if (t.length == 0) {
            return true;
        }

        for (int i = t.length - 1; i > 0; i--) {
            for (int j = 0; j < t[i].length; j++) {
                if (t[i][j] < t[i - 1][j]) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Checks if all the cells are between 1 to n
     * where n is the total number of cells.
     * Create duplicates arraylist to catch duplicate  
     * values.
     *
     * @param t a two-dimensional array which represents a tableau.
     *
     * @return a boolean true or false.
     */

    public static boolean isSetOf1toN(int[][] t) {
        int n = 0;
        int rows = t.length;

        if (t.length == 0) {
            return true;
        }

        for (int i = 0; i < rows; i++) {
            n += t[i].length;
        }

        ArrayList < Integer > duplicates = new ArrayList < Integer > ();

        for (int i = 0; i < t.length; i++) {
            for (int j = 0; j < t[i].length; j++) {
                if (t[i][j] > n || t[i][j] < 1 || 
                     duplicates.contains(t[i][j])) {
                    return false;
                }
                duplicates.add(t[i][j]);
            }
        }
        return true;
    }

}
