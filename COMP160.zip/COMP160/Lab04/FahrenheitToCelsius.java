import java.util.Scanner;
/**Lab 4 COMP160 S2 2016
  * This class converts Fahrenheit into Celcius
  * Theon Leong; 20 July 2016
  */

import java.util.Scanner;
public class FahrenheitToCelsius{
  public static void main(String[]args){
    convertFToC();
    convertFToC();
    convertFToC();
  }
  
  /** This method inputs Fahrenheit temp and prints statements including return of method toCelcius
    */
  public static void convertFToC(){
    Scanner scan = new Scanner(System.in);
    System.out.println("Enter Fahrenheit temperature");
    double fahrenheit = scan.nextDouble(); 
    System.out.println(fahrenheit + " degrees Fahrenheit is " + toCelsius(fahrenheit) + "degrees Celsius."); 
  }
  
  /** This method converts Fahrenheit to Celcius and returns a double value
    */
  public static double toCelsius(double fahr){
    int BASE = 32;
    double CONVERSION_FACTOR = 9.0/ 5.0;
    double celsius = (fahr - BASE) / CONVERSION_FACTOR; 
    return celsius;
  }
}
