/* Lab 25, Theon Leong
 * Support Class for Algorithm contains sorting methods
 * It also has methods to set the size and initialise an array
 * This would allow multiple arrays to be created / sorted in the main method
 */

import java.util.ArrayList;
import java.util.Scanner;
import java.util.*;

public class Algorithm {
  protected static int elements;
  /* Set numbers of elements in the array
   */
  public static void setelements() { 
    try {
      Scanner s = new Scanner(System.in);
      System.out.println("How many items are in this list?");
      elements = s.nextInt();
    } catch (Exception e) {
      System.out.println("Please enter a number!");
    }
  }
  /* Initialise array
   */
  public static void initialise(int[] a) {    
    try {
      for(int i = 0; i < elements; i++) {
        Scanner s = new Scanner(System.in);
        a[i] = s.nextInt();
      }
    } catch (Exception e) {
      System.out.println("Please enter an integer!");
    }
  }
  
  /* Selection Al: Number at position 0 (index) will check the next position for the length of the array
   * If it is smaller than some other number, swap these numbers, and repeat this process till the smallest
   * number is on one end and the largest is on the other.
   */
  
  public static void selectionsort(int[] a) {
    for(int i = 0; i < a.length - 1; i++) {
      int index = i;
      for (int j = i + 1; j < a.length; j++) {
        if(a[j] < a[index]) {
          index = j;
        }
      }
      int temp = a[index];
      a[index] = a[i];
      a[i] = temp;
    }
  }
  
  /* Insertion Al: No index. For the length of the array, if j position is larger than it's previous position
   * swap the two numbers. Repeat until array is sorted in ascending order.
   */
  
  public static void insertionsort(int[] a) {
    for (int i = 0; i < a.length; i++) {
      for(int j = i; j > 0; j--) {
        if(a[j] > a[j-1]) {
          int temp = a[j];
          a[j] = a[j-1];
          a[j-1] = temp;
        }
      }
    }
  }
}