/* Lab 25, Theon Leong
 * Application Class inherits methods and variables from Algorithm
 * Arrays are declared in the main method and methods applied before printing on console
 */

public class AlgorithmApp extends Algorithm {
  
  public static void main(String[] args) {   
    
    setelements();
    int[] numbers = new int[elements];
    
    if(elements > 0) { 
      initialise(numbers);
    }
    
    selectionsort(numbers);
    System.out.println(java.util.Arrays.toString(numbers));
    
    insertionsort(numbers);
    System.out.println(java.util.Arrays.toString(numbers));
  }
}