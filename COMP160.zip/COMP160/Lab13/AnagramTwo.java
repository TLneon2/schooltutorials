/** Application class for AnagramTwo
  * Lab 13 COMP160, Theon Leong
  */

import java.util.Scanner;

class AnagramTwo {
  private static String firstp;
  private static String secondp;
  private static String sorted1;
  private static String sorted2;
  private static int i;
  
  public static void main(String args[]) {
    
    Scanner input = new Scanner(System.in);    
    System.out.println("Enter first phrase: ");
    String firstp = input.nextLine().toLowerCase();
    
    System.out.println("Enter second phrase: "); 
    String secondp = input.nextLine().toLowerCase();
    
    sorted1 = order(firstp);
    System.out.println(firstp + " are the letters of " + sorted1 + " in order.");
    sorted2 = order(secondp);
    System.out.println(secondp + " are the letters of " + sorted2 + " in order.");
    
    if (sorted1.equals(sorted2)) {
      System.out.println(firstp + " is an anagram of " + secondp);
    }
    else
      System.out.println("no anagram");
  }
  
  /** Method to return correctly ordered second phrase
  */
  public static String order(String input) {
    char var;
    char test;
    String sorted = "";
    for (var = 'a'; var <= 'z'; var++) {
      for (i = 0; i < input.length(); i++) {
        test = input.charAt(i);
        if (test == var) {
          sorted += Character.toString(test);
        }
      }
    }
    return sorted;
  }
}