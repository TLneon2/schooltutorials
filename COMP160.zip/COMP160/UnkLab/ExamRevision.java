class ExamRevision {
  
  public static void main(String[] args) {
    System.out.println(Math.floor(3.7));
    System.out.println(10%15);
  }
}

