class ExamRevisionTwo {
  
  private static double price = 15.0;
  private static double returnprice;
  
  public static double getPrice(int age) {
    
    if (age <= 5) {
      returnprice = 0.0;
    }
    
    else if (age <= 18 || age >= 65) {
      returnprice = price / 2;
    }
    
    else {
      returnprice = price;
    }
    
    return returnprice;
  }
  
  public static void main(String[] args) {
    System.out.println(getPrice(68)); 
  }
}