class practice {
  public static void main(String args[]) {
   int iResult;
   double fResult;
   
   iResult = Math.round(3.2);
   
   System.out.println("The ans is " + iResult);
  }
}