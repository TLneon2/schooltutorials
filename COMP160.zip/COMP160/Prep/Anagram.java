import java.util.Scanner;
import java.util.Arrays;

class Anagram {
  private static String firstp;
  private static String secondp;
  private static char max;
  private static int i;
  
  public static void main(String args[]) {
    
    Scanner input = new Scanner(System.in);
    
    System.out.println("Enter first phrase: ");
    String firstp = input.next();
    if (isInputValid(firstp) == false) {
      System.out.println("Invalid entry. Don't put spaces or punctuation marks!");
    }
    firstp.replace(" ", "");    
    
    char [] firstpArr = firstp.toCharArray();
    
    System.out.println("Enter second phrase: "); 
    String secondp = input.next();
    if (isInputValid(secondp) == false) {
      System.out.println("Invalid entry. Don't put spaces or punctuation marks!");
    }
    secondp.replace(" ","");
    
    char [] secondpArr = secondp.toCharArray();
    
    Arrays.sort(firstpArr);
    Arrays.sort(secondpArr);    
    
    for (char value : firstpArr) {
      System.out.print(value);
    }
    System.out.print(" are the letters of " + firstp + " in order.");
    
    System.out.println();
    
    for (char value : secondpArr) {
      System.out.print(value);
    }
    System.out.print(" are the letters of " + secondp + " in order.");
    
    System.out.println();
    
    boolean test = Arrays.equals(firstpArr, secondpArr);
    if (test == true) {
      System.out.println(firstp + " is an anagram of " + secondp);
    }
    else
      System.out.println("no anagram");
  }
  
  public static boolean isInputValid(String input){
    boolean var = true;
    
    for (int i = 0; i < input.length(); i++) {
      char ch = input.charAt(i);
      if (!(Character.isLetter(ch))) {
        var = false; }
    }
    return var;
  }
}

