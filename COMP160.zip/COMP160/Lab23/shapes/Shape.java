/** Abstract support class Shape.java
  * Lab 23, COMP160,  2016
  * Constructs shape objects
  */

package shapes;
import java.awt.*;
import java.math.*;

public abstract class Shape {
  protected int x;
  protected int y;
  protected int width;
  protected int height;
  protected Color colour;
  protected int moveX = 1;
  protected int moveY = 1;
  
  /** Constructs a shape with width, height, x, y and color values in random
    */  
  public Shape() {
    width = randomRange(10, 30);
    height = width;
    x = randomRange(0, 400 - width);
    y = randomRange(0, 400 - height);
    colour = new Color(randomRange(0,255), randomRange(0,255), randomRange(0,255));
    
    if (y >= 200) {
      moveY = -moveY;
      moveX = -moveX;
    }
  }
  
  /** Creates random digits with random java function formula
    */  
  public int randomRange(int lo, int hi) {
    return (lo + (int)(Math.random()*((hi-lo)+1)));
  }
  
  /** Moves Shape objects based on moveX and moveY
    */  
  public void move () {
    if(width >= 15) {
      moveX = 0;
    }
    if (x == (400-width) || x == 0) {
      moveX = -moveX;
    }   
    if (y == (400-height) || y == 0) {
      moveY = -moveY;  
    }
    x += moveX;
    y += moveY;
  }
  
  /** Enlarges all circles after 6000 milliseconds
    */  
  public void enlarge () {
    width = 40;
    height = 40;
  }
  
  /** Abstract display methods forces subclass displays 
    */
  public abstract void display(Graphics g);
}