/** Application class for VowelsConsonants
  * Lab 11 COMP160, Theon Leong
  */

import java.util.Scanner;

class VowelsConsonants {
  private String sentence;
  private static char sen;
  private int i;
  private static int count;
  private static int count2;
  
  /** User makes input, for loop checks each character for vowels and counts them,
    * everything else is an consonant count, isLetter checks if each character is a letter
    */
  public static void main(String []args) {
    Scanner input = new Scanner(System.in);
    System.out.println("Enter a sentence: ");
    String sentence = input.nextLine();
    
    for (int i = 0; i < sentence.length(); i++) {
      char sen = sentence.charAt(i);
      if (Character.isLetter(sen)) {
        switch(sen) {
          case 'a':
          case 'e':
          case 'i':
          case 'o':
          case 'u':  
            count++;
            break;
          default: 
            count2++;
            break;
        }        
      }
    }
    System.out.println("Sentence is: " + sentence);
    System.out.println("Vowel count: " + count);
    System.out.println("Consonant count: " + count2);
  }
}
