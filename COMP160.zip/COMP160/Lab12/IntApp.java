/** Application class for IntApp
  * Lab 11 COMP160, Theon Leong
  */

import java.util.Scanner;

class IntApp {
  private int num;
  private static int i = 2;
  private static int sum;
  
  /** User makes input, first if checks if input is valid
    * second if calculates the sum
    */
  public static void main(String []args) {
    Scanner input = new Scanner(System.in);
    System.out.println("Enter an integer greater than 1: ");
    int num = input.nextInt();
    
    if (num < 2) {
      System.out.println("Input value must not be less than 2");
    }
    else {
      while(i <= num) {
        if (i % 2 == 0){
          sum = sum + i;
        }
        i++; 
      }
      System.out.println("Sum of even numbers between 2 and " + num + " inclusive is: " + sum);        
    }   
  }
}