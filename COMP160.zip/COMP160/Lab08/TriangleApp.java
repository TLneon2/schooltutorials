/**
 * TriangleApp.java
 * Lab 8, Part 1, COMP160  2016
 * Main class that prints results
 */
import java.text.DecimalFormat;

public class TriangleApp {  
  
/**
 * Creates three triangles and prints out their properties
 */
  public static void main (String[]args) {
    DecimalFormat fmt = new DecimalFormat("0.##");
    
    Triangle a = new Triangle(0, 0, 3, 0, 3, 4, "A");
    Triangle b = new Triangle(6, 5, 4, 3, 2, 1, "B");
    Triangle c = new Triangle(1, 2, 3, 4, 5, 7, "C");
    
    System.out.println("The Triangle " + a.getName() + " has the perimeter of " + a.getPerimeter());
    System.out.println("The Triangle " + b.getName() + " has the perimeter of " + fmt.format(b.getPerimeter()));
    System.out.println("The Triangle " + c.getName() + " has the perimeter of " + fmt.format(c.getPerimeter()));
    
  }
}