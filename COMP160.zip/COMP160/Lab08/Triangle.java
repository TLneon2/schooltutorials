import static java.lang.Math.sqrt;
import static java.lang.Math.pow;
/**
 * Triangle.java
 * Lab 8, Part 1, COMP160  2016
 * Support class that calculates sides and perimeters.
 */

public class Triangle {  
  
  private int p1x;
  private int p1y;
  private int p2x;
  private int p2y;
  private int p3x;
  private int p3y;
  private String name;
  
  /**
 * Contructs a Triangle by passing in values
 */
  public Triangle (int x1, int y1, int x2, int y2, int x3, int y3, String nameIn) {
    p1x = x1;
    p1y = y1;
    p2x = x2;
    p2y = y2;
    p3x = x3;
    p3y = y3;
    name = nameIn;
    
  }
  /** Calculates Sides using Pythagoras theorem
 */
  public double calcSide(int v1, int va1, int v2, int va2) {
    
    double length = sqrt(pow((v2 - v1), 2) + pow((va2 - va1), 2));
    
    return length;
    
  }

  /** Calculates Perimeter using Sides
 */
  public double getPerimeter() {
    
    double perimeter = calcSide(p1x, p1y, p2x, p2y) + calcSide(p1x, p1y, p3x, p3y) 
      + calcSide(p2x, p2y, p3x, p3y);
    
    return perimeter;
    
  }
  
  /** Returns the name of the Triangle
 */
  public String getName() {
    return name;
  }
  
}