/** Lab 2 COMP160 Part 1 TwoNumbersApp.java
  * Theon Leong July 2016
  */
public class TwoNumbersApp {
  public static void main (String[] args) {
    double num1;
    double num2;
    num1 = 8.5;
    num2 = 15.0;
    System.out.println("First number is " + num1);
    System.out.println("Second number is " + num2);
    System.out.println("Sum is " + (num1 + num2));
  }
}
