/**
 Pie.java
 Theon Leong 250716
 */

import javax.swing.*;
import java.awt.*;

/**inheritence and displaying chart
   */
public class Pie extends JFrame{
  
  public static void main(String[]args){
    
    Pie chart1 = new Pie(); 
    chart1.setSize(300,220);
    chart1.setVisible(true);
  }
  
/**This method has constant values and draws a pie chart with blue set apart
  */
  public void paint (Graphics page){
    final int pi = 360;
    final int x = 75;
    final int y = 25;
    final int width = 150;
    final int height = 180;
    final int arc =45;
    
    page.setColor(Color.white);
    page.fillRect(0,0,300,220);
    
    page.setColor(Color.blue);
    page.fillArc (x+25,y-10,width,height,pi -360,arc);
    
    page.setColor(Color.cyan);
    page.fillArc (x,y,width,height,pi -315,arc);
    
    page.setColor(Color.gray);
    page.fillArc (x,y,width,height,pi -270,arc);
    
    page.setColor(Color.green);
    page.fillArc (x,y,width,height,pi -225,arc);
    
    page.setColor(Color.magenta);
    page.fillArc (x,y,width,height,pi -180,arc);
    
    page.setColor(Color.pink);
    page.fillArc (x,y,width,height,pi -135,arc);
    
    page.setColor(Color.yellow);
    page.fillArc (x,y,width,height,pi -90,arc);
    
    page.setColor(Color.red);
    page.fillArc (x,y,width,height,pi -45,arc);
  }
}
