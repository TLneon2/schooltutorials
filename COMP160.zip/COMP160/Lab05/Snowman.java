/**
 Theon Leong 250716
 */

import javax.swing.*;
import java.awt.*;

public class Snowman extends JFrame{
  
  public static void main(String[]args){
    Snowman frame = new Snowman();  
    frame.setSize(300,220);
    frame.setVisible(true);
  }
  
  /**  Draws a snowman.*/
  public void paint (Graphics page)
  {
    final int MID = 60;
    final int TOP = 60;
    setTitle("Snowman");
    
    page.setColor (Color.cyan);
    page.fillRect(0,0,300,220);  //background;
    
    page.setColor (Color.red);
    page.drawString ("Theon Leong", 0, 35); //draw String
    
    page.setColor (Color.blue);
    page.fillRect (0, 175, 300, 50);  // ground
    
    page.setColor (Color.yellow);
    page.fillOval (270, -40, 80, 90);  // sun
    
    page.setColor (Color.white);
    page.fillOval (MID -20, TOP, 40, 40);      // head
    page.fillOval (MID - 35, TOP + 35, 70, 50);   // upper torso    
    page.fillOval (MID - 50, TOP + 80, 100, 60);  // lower torso
    
    page.setColor (Color.red);
    page.fillOval (MID -5, TOP+45, 10, 10);
    page.fillOval (MID -5, TOP+65, 10, 10); //two red buttons

    page.setColor (Color.black);
    page.fillOval (MID - 10, TOP + 10, 5, 5);   // left eye
    page.fillOval (MID + 5, TOP + 10, 5, 5);    // right eye
    
    page.drawArc (MID - 10, TOP + 20, 20, 10, -190, -160);   // frown
    
    page.drawLine (MID - 25, TOP + 60, MID - 50, TOP + 40);  // left arm
    page.drawLine (MID + 25, TOP + 60, MID + 55, TOP + 60);  // right arm
    
    page.drawLine (MID - 20, TOP + 5, MID + 20, TOP + 5);  // brim of hat
    page.fillRect (MID - 15, TOP - 20, 30, 25);        // top of hat
  }
}
