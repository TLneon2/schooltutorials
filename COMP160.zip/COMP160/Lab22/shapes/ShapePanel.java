/** Application class Shape.java
  * Lab 22, COMP160,  2016
  */

package shapes;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class ShapePanel extends JPanel {
  private Shape[] shapes = new Shape[20];
  private DrawingPanel drawPanel;
  private JPanel controlPanel;
  private JButton addShape, Start, Stop;
  private JTextField showNum;
  private JLabel countLabel;
  private int count = 0;
  private int i;
  Timer timer, timer2;
  private final int DELAY = 10;
  
  /** Panel creates buttons, labels and sets actionlistener to addShape
    * It adds drawPanel and controlPanel
    * 2 timers are created for movement for circles
    * actionlistener is assigned to the timers as well
    * Panel adds 2 timers: timer (movement) and timer2 (enlarges)
    */  
  public ShapePanel() {
    controlPanel = new JPanel();
    addShape = new JButton();
    addShape.setText("Add Shape");
    showNum = new JTextField(2);
    countLabel = new JLabel();
    countLabel.setText("Count");
    Start = new JButton();
    Start.setText("Start");
    Stop = new JButton();
    Stop.setText("Stop");
    
    ButtonListener bl = new ButtonListener();
    addShape.addActionListener(bl);
    Start.addActionListener(bl);
    Stop.addActionListener(bl);
    
    timer = new Timer(DELAY, bl);
    timer2 = new Timer(DELAY+6000, bl);
    
    controlPanel.setPreferredSize(new Dimension(100,400));
    controlPanel.add(addShape);
    controlPanel.add(showNum);
    controlPanel.add(countLabel);
    controlPanel.add(Start);
    controlPanel.add(Stop);
    add(controlPanel);
    
    drawPanel = new DrawingPanel();
    add(drawPanel);
    
    setBackground(Color.yellow);
  }
  
  public static void main(String[] args) {
    JFrame frame = new JFrame();
    frame.getContentPane().add(new ShapePanel());
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.pack();
    frame.setVisible(true);
    frame.setTitle("Lab 22");
  }
  
  /** Inner class for DrawingPanel
    * paintComponent method displays shapes
    * as they are put into the array
    */  
  private class DrawingPanel extends JPanel {
    
    public DrawingPanel() {
      setPreferredSize(new Dimension(400,400));
      setBackground(Color.pink);
    }
    
    public void paintComponent(Graphics g){
      super.paintComponent(g);
      for(i = 0; i < count; i++){
        shapes[i].display(g);
      } 
    }
  }
  
  /** ActionListener inner class for button
    * It creates a new shape per button press
    * regardless of whether the button was pressed
    * count is incremented and displayed
    * 
    * When timer start button is pressed, 2 timers start
    * Each shape will use a support move method
    * 6000ms later, all shapes will be enlarged
    */  
  private class ButtonListener implements ActionListener {
    
    public void actionPerformed(ActionEvent e) {
      if (e.getSource() == addShape) {
        if(count < shapes.length) {
          shapes[count] = new Shape();
          count++;
        }
      }
      else if(e.getSource() == timer) {
        for(i = 0; i < count; i++) {
          shapes[i].move();
        }
      }
      if(e.getSource() == timer2) {
        for(i = 0; i < count; i++) {
          shapes[i].enlarge();
        }
      }
      else if(e.getSource() == Stop) {
        timer.stop();
        timer2.stop();
      }
      else if(e.getSource() == Start) {
        timer.start();
        timer2.start();
      }
      showNum.setText("" + count);
      drawPanel.repaint();
    }
  }
}