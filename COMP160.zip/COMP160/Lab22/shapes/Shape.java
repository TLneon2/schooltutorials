/** Support class Shape.java
  * Lab 22, COMP160,  2016
  * Constructs Circles
  */

package shapes;
import java.awt.*;
import java.math.*;

public class Shape {
  private int x;
  private int y;
  private int width;
  private int height;
  private Color colour;
  private int moveX = 1;
  private int moveY = 1;
  
  /** Constructs a shape with width, height, x, y and color values in random
    */  
  public Shape() {
    width = randomRange(10, 30);
    height = width;
    x = randomRange(0, 400 - width);
    y = randomRange(0, 400 - height);
    colour = new Color(randomRange(0,255), randomRange(0,255), randomRange(0,255));
    
    if (y >= 200) {
      moveY = -moveY;
      moveX = -moveX;
    }
  }
  
  /** Creates random digits with random java function formula
    */  
  public int randomRange(int lo, int hi) {
    return (lo + (int)(Math.random()*((hi-lo)+1)));
  }
  
  /** Draws fillOval objects and set colours via graphics
    */  
  public void display (Graphics g) {
    g.setColor(colour);
    g.fillOval(x,y,width,height);
  }
  
  /** Moves Shape objects based on moveX and moveY
    */  
  public void move () {
    if(width >= 15) {
      moveX = 0;
    }
    if (x == (400-width) || x == 0) {
      moveX = -moveX;
    }   
    if (y == (400-height) || y == 0) {
      moveY = -moveY;  
    }
    x += moveX;
    y += moveY;
  }
  
  /** Enlarges all circles after 6000 milliseconds
    */  
  public void enlarge () {
    width = 40;
    height = 40;
  }
}