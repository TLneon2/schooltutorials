/** Support class for DinerApp
  * Lab 15 COMP160, Theon Leong
  */

class IntCounter {
  int[] numArray;
  
  /** Takes it array argument and sets it to data field array
    * prints out array elements and length
    */  
  public IntCounter(int[] numArray) {
    this.numArray = numArray;
    for(int element:numArray) {
      System.out.print(element + " "); 
    }
    System.out.println("Array is of length " + numArray.length);
  }
  /** Method that finds target value and returns the index position
    * of value
    */  
  public void showTarget(int target) {
    for(int i = 0; i < numArray.length; i++) {
      if (numArray[i] == target) {
        System.out.println("There is a " + target + " in position " + i); 
      }    
    }    
  }
}