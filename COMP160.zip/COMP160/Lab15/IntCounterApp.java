/** Application class for DinerApp
  * Lab 15 COMP160, Theon Leong
  */

import java.util.Scanner;
import java.util.Random;

class IntCounterApp {
  
  public static void main(String[] args) {
    for(int i = 0; i < 3; i++) {
      Scanner s = new Scanner(System.in);
      System.out.println("Which number do you wish to find?");
      int target = s.nextInt();
      IntCounter intcounter = new IntCounter(makeArray());
      intcounter.showTarget(target);
    }
  }

/** Make array size from random digits from 5 to 10
  * Next, populate it with digits between 0 to 4
  * returns array value
  */
  public static int[] makeArray() {
    Random randomno = new Random();
    int randomNum = 5 + (int)(Math.random() * 6);
    int[] randomarray = new int[randomNum];
    for (int i = 0; i < randomarray.length; i ++) {
      randomarray[i] = randomno.nextInt(4);
    }
    return randomarray;
  }
}