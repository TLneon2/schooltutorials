/** Application class for FruitNames
  * Lab 16 COMP160, Theon Leong
  */

import java.util.*;

class FruitNames {
  private static boolean dowhile; //this boolean controls the repetition of the loop based on user input
  
  public static void main(String[] args) {
    String[] fruits = new String[3];
    
    for(int i = 0; i < fruits.length; i++) {
      Scanner s = new Scanner(System.in);
      System.out.println("Enter the name of a fruit?");
      String fruit = s.nextLine();
      fruits[i] = fruit;
    }
    
    for(String element:fruits) {
      do {
        System.out.print("Guess what fruit I am?");
        System.out.print("    " + element.substring(0,2));
        System.out.println("    " + element.length() + " letters");
        Scanner s = new Scanner(System.in);
        String guess = s.nextLine();
        if (guess.equals(element)) {
          System.out.println("Correct");
          dowhile = false;
        } else {
          System.out.println("Try again");
          dowhile = true; 
        }
      } while (dowhile == true);
    } 
  }
}