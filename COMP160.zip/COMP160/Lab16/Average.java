/** Application class for Average
  * Lab 16 COMP160, Theon Leong
  */

public class Average {
  private static double average = 0;
  private static double sum = 0.0;
  
  public static void main(String[] args) {
    
    int [] [] table = {{1, 2, 3},{4,5,6},{7,8}};
    
    for(int rows[] :table) {
      for(int element:rows) {
        System.out.print(element + " ");
        sum += element;
        average = sum / rows.length;
      }
      System.out.print("\tAverage  :  " + average);
      sum = 0;
      average = 0.0;
      System.out.println();
    }
    
  }
}