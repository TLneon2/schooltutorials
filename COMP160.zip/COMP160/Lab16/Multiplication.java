/** Application class for Multiplication
  * Lab 16 COMP160, Theon Leong
  */

class Multiplication {
  
  public static void main(String[] args) {
    int cols = 12;
    int rows = 12;
    
    int [] [] multi = new int [rows] [cols];
    
//populates 2D array   
    for (int i = 0; i < rows; i++) {
      for(int j = 0; j< cols; j++) {
        multi [i] [j] = (i+1) * (j+1);
      }
    }
    
//prints 2D array    
    for(int[] row:multi) {
      for(int element:row) {
        System.out.print(element + "\t");
      }
      System.out.println();
    }
  }
}