/** Application class Shape.java
  * Lab 21, COMP160,  2016
  */

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class ShapePanel extends JPanel {
  private Shape[] shapes = new Shape[20];
  private DrawingPanel drawPanel;
  private JPanel controlPanel;
  private JButton addShape;
  private JTextField showNum;
  private JLabel countLabel;
  private int count = 0;
  private int i;
  
  /** Panel creates buttons, labels and sets actionlistener to addShape
    * It adds drawPanel and controlPanel
    */  
  public ShapePanel() {
    controlPanel = new JPanel();
    addShape = new JButton();
    addShape.setText("Add Shape");
    showNum = new JTextField(2);
    countLabel = new JLabel();
    countLabel.setText("Count");
    
    ButtonListener bl = new ButtonListener();
    addShape.addActionListener(bl);
    
    controlPanel.setPreferredSize(new Dimension(100,400));
    controlPanel.add(addShape);
    controlPanel.add(showNum);
    controlPanel.add(countLabel);
    add(controlPanel);
    
    drawPanel = new DrawingPanel();
    add(drawPanel);
    
    setBackground(Color.yellow);
  }
  
  public static void main(String[] args) {
    JFrame frame = new JFrame();
    frame.getContentPane().add(new ShapePanel());
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.pack();
    frame.setVisible(true);
    frame.setTitle("Lab 21");
  }
  
  /** Inner class for DrawingPanel
    * paintComponent method displays shapes
    * as they are put into the array
    */  
  private class DrawingPanel extends JPanel {
    
    public DrawingPanel() {
      setPreferredSize(new Dimension(400,400));
      setBackground(Color.pink);
    }
    
    public void paintComponent(Graphics g){
      super.paintComponent(g);
      for(i = 0; i < count; i++){
        shapes[i].display(g);
      } 
    }
  }
  
  /** ActionListener inner class for button
    * It creates a new shape per button press
    * regardless of whether the button was pressed
    * count is incremented and displayed
    */  
  private class ButtonListener implements ActionListener {
    
    public void actionPerformed(ActionEvent e) {
      if (e.getSource() == addShape) {
        if(count < shapes.length) {
          shapes[count] = new Shape();
          count++;
        }
      }
      showNum.setText("" + count);
      drawPanel.repaint();
    }
  }
}