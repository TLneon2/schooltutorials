/** Support class Shape.java
  * Lab 21, COMP160,  2016
  * Constructs Circles
  */

import java.awt.*;
import java.math.*;

public class Shape {
  private int x;
  private int y;
  private int width;
  private int height;
  private Color colour;

  /** Constructs a shape with width, height, x, y and color values in random
  */  
  public Shape() {
    width = randomRange(10, 30);
    height = width;
    x = randomRange(0, 400 - width);
    y = randomRange(0, 400 - height);
    colour = new Color(randomRange(0,255), randomRange(0,255), randomRange(0,255));
  }
  
  /** Creates random digits with random java function formula
    */  
  public int randomRange(int lo, int hi) {
    return (lo + (int)(Math.random()*((hi-lo)+1)));
  }
  
  /** Draws fillOval objects and set colours via graphics
    */  
  public void display (Graphics g) {
    g.setColor(colour);
    g.fillOval(x,y,width,height);
  }
  
}