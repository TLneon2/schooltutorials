/** 
 * StyleOptions.java Application Class
 * Lab 19, COMP160,  2016
 */

import javax.swing.JFrame;
import java.awt.*;
import javax.swing.*;

public class StyleOptions
{
   //-----------------------------------------------------------------
   //  Creates and presents the program frame.
   //-----------------------------------------------------------------
   public static void main (String[] args)
   {
      JFrame frame = new JFrame ("Style Options");
      frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);

      StyleOptionsPanel panel = new StyleOptionsPanel();
      panel.setLayout(new GridLayout(6,0));
      
      frame.getContentPane().add (panel);
      
      frame.pack();
      frame.setVisible(true);
   }
}
