/** 
 * StyleOptions.java Support Class
 * Lab 19, COMP160,  2016
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class StyleOptionsPanel extends JPanel
{
  private JLabel saying;
  private JCheckBox bold, italic;
  private JRadioButton courier, timesnewroman, helvetica;
  private int style =Font.PLAIN;
  private String typeFace = "Helvetica";
  
  //-----------------------------------------------------------------
  //  Sets up a panel with a label and some check boxes that
  //  control the style of the label's font.
  //-----------------------------------------------------------------
  public StyleOptionsPanel()
  {
    saying = new JLabel ("Say it with style!");
    saying.setFont (new Font (typeFace, style, 20));
    
    bold = new JCheckBox ("Bold");
    bold.setBackground (Color.cyan);
    italic = new JCheckBox ("Italic");
    italic.setBackground (Color.cyan);
    ButtonGroup group = new ButtonGroup();
    courier = new JRadioButton("Courier");
    timesnewroman = new JRadioButton("Times New Roman");
    helvetica = new JRadioButton("Helvetia");
    
    StyleListener listener = new StyleListener();
    
    ActionListener a = new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if (courier == source) {
          saying.setFont(new Font("Courier", style, 20));
          typeFace = "Courier";
        }
        else if(timesnewroman == source) {
          saying.setFont(new Font("Times New Roman", style, 20));
          typeFace = "Times New Roman";
        }
        else if(helvetica == source) {
          saying.setFont(new Font("Helvetica", style, 20));
          typeFace = "Helvetica";
        }
      }
    };
    
    courier.addActionListener(a);
    timesnewroman.addActionListener(a);
    helvetica.addActionListener(a);
    
    bold.addItemListener (listener);
    italic.addItemListener (listener);
    courier.addItemListener (listener);
    timesnewroman.addItemListener(listener);
    helvetica.addItemListener(listener);
    
    add (saying);
    add (bold);
    add (italic);
    add(courier);
    group.add(courier);
    add(timesnewroman);
    group.add(timesnewroman);
    add(helvetica);
    group.add(helvetica);
    
    setBackground (Color.cyan);
    setPreferredSize (new Dimension(300, 100));
  }
  
  //*****************************************************************
  //  Represents the listener for both check boxes.
  //*****************************************************************
  private class StyleListener implements ItemListener
  {
    //--------------------------------------------------------------
    //  Updates the style of the label font style.
    //--------------------------------------------------------------
    public void itemStateChanged (ItemEvent event)
    {
      style = Font.PLAIN;
      Font font = new Font("Courier", Font.PLAIN, 20);  
      
      if (bold.isSelected())
        style = Font.BOLD;
      
      if (italic.isSelected())
        style += Font.ITALIC;
      
      saying.setFont(new Font(typeFace, style, 20));
    }
  }
}
