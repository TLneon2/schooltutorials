/** Support class for DinerApp
  * Lab 14 COMP160, Theon Leong
  */

import java.awt.*;

public class Diner {
  
  private int x;
  private int y;
  private String name;
  private int seatNum;
  private Color colour;
  private final int DIAMETER = 50;
  
  /** Constructs diner and sets inputted values to data fields
    */  
  public Diner (int a, int b, String n, int s, Color c) {
    x = a;
    y = b;
    name = n;
    colour = c;
    seatNum = s;
  }
  
  /** Draw method that draws circles, set colors, set fonts and draws strings
    */
  public void draw(Graphics g) {
    g.setColor(colour);
    g.fillOval(x, y, DIAMETER, DIAMETER);
    g.setColor(Color.black);
    
    g.setFont(new Font("Courier", Font.PLAIN, 10));
    g.drawString(name, x+5, y+25);
    
    g.setFont(new Font ("Helvetica", Font.PLAIN, 8));
    g.drawString( Integer.toString(seatNum),x+25 ,y+10);
  }
}