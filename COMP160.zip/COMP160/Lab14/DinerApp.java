/** Application class for DinerApp
  * Lab 14 COMP160, Theon Leong
  */

import java.awt.*;
import javax.swing.*;

class DinerApp {
  
  public static void main(String[] args) {
    JFrame frame = new JFrame("Diner");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.getContentPane().add(new TablePanel());
    frame.pack();
    frame.setVisible(true);
  }
}