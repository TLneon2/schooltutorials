/** Support class for DinerApp
  * Lab 14 COMP160, Theon Leong
  */

import java.awt.*;
import javax.swing.*;

/** Creates Jpanel and constructs diners
  */
public class TablePanel extends JPanel {
private Diner diner1, diner2, diner3, diner4, diner5, diner6;

  public TablePanel() {
    
    diner1 = new Diner(120,70,"David",1,Color.blue);
    diner2 = new Diner(60,120,"Jacqul",6,Color.blue);
    diner3 = new Diner(60,180,"Todd",5,Color.blue);
    diner4 = new Diner(120,230,"Metiria",4,Color.red);
    diner5 = new Diner(180,180,"Michael",3,Color.blue);
    diner6 = new Diner(180,120,"Clare",2,Color.red);
    
    setPreferredSize(new Dimension(300,300));
    setBackground(Color.gray);
  }
  
/** Calls paintComponent and applies draw method to diner objects; draws table
  */  
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    diner1.draw(g);
    diner2.draw(g);
    diner3.draw(g);
    diner4.draw(g);
    diner5.draw(g);
    diner6.draw(g);
    g.fillRect(120,130,50,90);
  }
}