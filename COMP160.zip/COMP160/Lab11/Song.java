/** Support class for SongApp
  * Lab 10 COMP160, Theon Leong
  */

class Song {
  
  private String songLine;
  
  /** Constructor to create song object
    */
  public Song (String input) {
    songLine = input;
  }
  
  /**Returns the new song instances for printing
    */
  public String toString () {
    return songLine;
  }
  
  /**processing the song in various ways using index, length and uppercase string methods
    */
  public void process() {
    
    int songLength = songLine.length();
    System.out.println("Length is: " + songLength);
    
    if (songLength == 0) {
      System.out.println("invalid entry.");
      System.out.println();
    }
    
    else if (songLength > 0) {
      
      char lastchar = songLine.charAt(songLine.length() - 1);
      System.out.println("Last char is: " + lastchar);
      
      int firstspace = songLine.indexOf(' ');
      int secondspace = songLine.indexOf(' ', firstspace + 1);
      int thirdspace = songLine.indexOf(' ', secondspace +1);
      
      if (secondspace > 0) {        
        String firstwords = songLine.substring(0, secondspace);
        String lastwords = songLine.substring(secondspace);
        
        System.out.println("first words are: " + firstwords);
        System.out.println("subsequent words are: " + lastwords);
        
        char firstletter = songLine.charAt(secondspace + 1);
        System.out.println("first letter of the third word is: " + firstletter);        
      }
      
      System.out.println(songLine.toUpperCase());
      
      System.out.println(songLine.replace(" ", "x")); 
      
      int first_b = songLine.indexOf('b');
      
      if (first_b > 0) { 
        System.out.println("first b is at index: " + first_b);
      }
      
      System.out.println(songLine);
      System.out.println();
      
    }
  }
}