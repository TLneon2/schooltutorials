/** Application class for Song
  * Lab 10 COMP160, Theon Leong
  */
class SongApp {
  
  /** Main method constructs new songs and processes them
    */
  public static void main(String[]args){
    Song song1 = new Song("while my guitar gently weeps");
    System.out.println(song1.toString());
    song1.process();
    
    Song song2 = new Song("let it be");
    System.out.println(song2.toString());
    song2.process();
    
    Song song3 = new Song("Penny Lane");
    System.out.println(song3.toString());
    song3.process();
    
    Song song4 = new Song("");
    song4.process();
    
    Song song5 = new Song("whatever you want");
    System.out.println(song5.toString());
    song5.process();
    
  }
}