/**  
 * Box.java
 * Lab 7, COMP160  2016
 * 
 * Constructs, Calculates & Mutates information about an individual Box.
 */

public class Box {
  
  private int height;
  private int width;
  private int length;
  
  public Box(int w,int h,int l) {
    height = h;
    width = w;
    length = l;
  }
  
  public Box() {} // multiple constructors with different arguments
  
  public Box(int input) {
    height = input; 
    width = input;
    length = input;
  }
  /**sets the value of the data field height to input parameter value */
  public void setHeight(int h){      
    height = h;      
  }
  /**sets the value of the data field width to input parameter value */
  public void setWidth(int w){      
    width = w;      
  }
  /**sets the value of the data field length to input parameter value */
  public void setLength(int l){      
    length = l;      
  }
  /**calculates the volume of Box*/
  public int getVolume(){
    int volume;
    volume = height * length * width;
    return volume;
  }
  /**calculates the surface area of Box*/
  public int getSurfaceArea(){      
    return 2*(height*width) +2*(width*length) + 2*(length*height);
  }
  
  /**returns the string of Box*/
  public String toString(){
    return ("The height is " + height + ". The width is " + width + ". The length is " + length + "."
              + " The volume is " + getVolume() + ". The surface area is " + getSurfaceArea() + ".");
  }
}