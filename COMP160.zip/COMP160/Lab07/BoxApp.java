/**  
 * BoxApp.java
 * Lab 7, COMP160  2016
 * Theon Leong
 * Stores and displays information about an individual Box.
 */

public class BoxApp {  
  
  public static void main (String[]args) {
    
    Box b1 = new Box();
    b1.setHeight(4);
    b1.setLength(4);
    b1.setWidth(6);
    
    System.out.println(b1.toString());
    
    Box b2 = new Box(3, 4, 5);
    System.out.println(b2.toString());
    
    Box b3 = new Box(5);
    System.out.println(b3.toString());
  }
}