/** Support class for TrafficLightPanel
  * Lab 18 COMP160, Theon Leong
  */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/** Panel class that creates buttons, adds listeners, constructs lightpanel 
  * and sets sizes and colors for these objects
  */
public class TrafficLightPanel extends JPanel {
  private JButton Red, Amber, Green;
  private JLabel buttonLabel, lastPressed;
  private JPanel buttonPanel;
  
  public TrafficLightPanel() {
    Red = new JButton("Red");
    Amber = new JButton("Amber");
    Green = new JButton("Green");
    
    ButtonListener listener = new ButtonListener();
    Red.addActionListener(listener);
    Amber.addActionListener(listener);
    Green.addActionListener(listener);
    
    buttonLabel = new JLabel("Button Panel");
    lastPressed = new JLabel("Last Pressed");
    
    buttonPanel = new JPanel();
    buttonPanel.setPreferredSize(new Dimension(80,290));
    buttonPanel.setBackground(Color.white);
    
    buttonPanel.add(buttonLabel);
    buttonPanel.add(Green);
    buttonPanel.add(Amber);
    buttonPanel.add(Red);
    
    setPreferredSize(new Dimension(200,300));
    setBackground(Color.blue);
    add(buttonPanel);
    
    LightPanel lightpanel = new LightPanel();
    add(lightpanel);
  }
/** Actionevent - when button is pressed, background color is changed
  */
  public class ButtonListener implements ActionListener {
    
    public void actionPerformed(ActionEvent e) {
      
      if (e.getSource() == Red) {        
        lastPressed.setText("Red");

      }
      else if (e.getSource() == Amber) {
        lastPressed.setText("Amber");

      }
      else if(e.getSource() == Green) {
        lastPressed.setText("Green");

      }
      repaint();
    }
  }
  
/** Graphics component draws circles for traffic light and changes
  * colors based on changes in label text.
  */  
  private class LightPanel extends JPanel {
    
    public void paintComponent(Graphics g) {
      super.paintComponent(g);
      g.setColor(Color.black);
      g.fillOval(20,30,40,40);
      g.setColor(Color.black);
      g.fillOval(20,80,40,40);
      g.setColor(Color.black);
      g.fillOval(20,130,40,40);
      
      String text = lastPressed.getText();
      if(text == "Red") {
        g.setColor(Color.red);
        g.fillOval(20,30,40,40);
      }
      else if(text == "Green") {
        g.setColor(Color.green);
        g.fillOval(20,130,40,40);
      }
      else if (text == "Amber") {
        g.setColor(Color.orange);
        g.fillOval(20,80,40,40);
      }
    }
    
    public LightPanel() {
      setPreferredSize(new Dimension(80,290));
      setBackground(Color.cyan);
    } 
  }
}