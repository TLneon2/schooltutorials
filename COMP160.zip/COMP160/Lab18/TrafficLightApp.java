/** Application class for TrafficLightPanel
  * Lab 18 COMP160, Theon Leong
  */

import javax.swing.JFrame;

public class TrafficLightApp {
  public static void main(String[] args) {
  JFrame frame = new JFrame("Traffic Light");
  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  frame.getContentPane().add(new TrafficLightPanel());
  frame.pack();
  frame.setVisible(true);
  }
}