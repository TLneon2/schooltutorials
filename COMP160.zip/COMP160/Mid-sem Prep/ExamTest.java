class ExamTest {
  
  private static int i = 20;
  private static String name = "Theon";

  public static void main(String[] args) {

  System.out.println(name.substring(0));
}
}