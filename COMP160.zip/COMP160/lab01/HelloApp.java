/**
 * Lab 1 COMP160 2016
 *theonleong July 2016
 */

public class HelloApp{
  
  public static void main (String[]  args) {
    System.out.println( "Hello World" );
 }
}
