/**
 * Lab 1 COMP160 2016
 */

public class Ex3App{
 public static void main(String[]  args) {
  System.out.println( "There were eight errors." );
  System.out.println( "Have you fixed them all?" );
  }
}
