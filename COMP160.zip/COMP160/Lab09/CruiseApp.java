/** application class for Customer.java
  * Lab 9 COMP160
  */

import java.text.DecimalFormat;
import java.util.Scanner;

public class CruiseApp{
/** Method to set ticket, meal and total price for each customer based on child, student or otherwise
  */  
  public static void confirmBooking(Customer customer) {
    DecimalFormat fmt = new DecimalFormat("0.00");
    
    double ticket = 56.00;
    double meal = 30.0;
    double totalprice; 
    
    boolean child = customer.isChild();
    boolean student = customer.isStudent();
    
    if (child == true) {
      ticket = ticket/2;
      meal = meal/2;
      totalprice = ticket + meal;
    } 
    else if (student == true) {
      ticket = ticket/2;
      meal = meal*9/10;
      totalprice = ticket + meal;
    }
    else {
      ticket = ticket*8/10;
      meal = meal*9/10;
      totalprice = ticket + meal;
    }
    
    System.out.println(" " + customer.getName()); 
    System.out.println(" Ticket price $" + fmt.format(ticket));
    System.out.println(" Meal Price: $" + fmt.format(meal));
    System.out.println(" Total price: $" + fmt.format(totalprice));
    
    Scanner input = new Scanner(System.in);
    System.out.println(" Enter Y to confirm: ");
    String book = input.next();
    
    if ("Y".equals(book) || "y".equals(book)) {
      customer.setBooked();
      System.out.println(" Booked");
    }
  }  
  
  public static void main(String[]args){
    
    //each Customer created with name, age, showed student ID card
    Customer customer1 = new Customer("Aaron Stott",17, true);
    Customer customer2 = new Customer("Betty Adams",17, false);
    Customer customer3 = new Customer("Corin Child",16, true);
    Customer customer4 = new Customer("Doris Stewart",25, true);
    Customer customer5 = new Customer("Edmond Cheyne",12, false);
    Customer customer6 = new Customer("Fiona Chaney",7, false);
    Customer customer7 = new Customer("Ged Still-Child",16, true);
    Customer customer8 = new Customer("Harry Adamson",20, false);
    confirmBooking(customer1);
    confirmBooking(customer2);
    confirmBooking(customer3);
    confirmBooking(customer4);
    confirmBooking(customer5);
    confirmBooking(customer6);
    confirmBooking(customer7);
    confirmBooking(customer8);
    showBooked(customer1);
    showBooked(customer2);
    showBooked(customer3);
    showBooked(customer4);
    showBooked(customer5);
    showBooked(customer6);
    showBooked(customer7);
    showBooked(customer8);
  }
/** Method to print customer's name if he / she is booked
  */    
  public static void showBooked(Customer customer) {
    if (customer.isBooked() == true) {
      System.out.println(customer.getName() + " is booked.");
    }
  }
}