/** support class for Customer.java
  * Lab 9 COMP160
  */

class Customer {
  private boolean child;
  private boolean student;
  private String name;
  private boolean booked;

  /** constructs a new customer with name, student and child data fields
  */
  public Customer (String nameIn, int age, boolean studentIn) {
    name = nameIn;
    student = studentIn;
    child = 5 <= age && age <= 16;
  }
  /** if child, return true
  */
  public boolean isChild () {
    return child;
  }
  /** if student, return true
  */
  public boolean isStudent () {
    return student;
  }
  /** returns String value
  */
  public String getName () {
    return name;
  }
  /** if Booked, return true.
  */
  public Boolean isBooked() {
    return booked;
  }
  /** if Booked, return true. Based on customer input.
  */
  public void setBooked() {
      booked = true;
  }
  
}
