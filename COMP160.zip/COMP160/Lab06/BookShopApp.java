/**  
 * BookShopApp.java
 * Lab 6, COMP160  2016
 * Theon Leong
 * Stores and displays information about an individual Book.
 */

public class BookShopApp {  
  
  public static void main (String[]args) {
    //Set details for book1
    Book book1 = new Book();
    book1.displayBook();
    book1.setTitle("Life of Pi");
    book1.setPages(348);
    book1.setPrice(28.90);  
    
    // Set details for book2
    Book book2 = new Book();
    book2.setTitle("Mister Pip");
    book2.setPages(240);
    book2.setPrice(22.70);
    
    // Set details for book3
    Book book3 = new Book();
    book3.setTitle("Kafka By The Shore");
    book3.setPages(450);
    book3.setPrice(21.00);
    
    // print everything
    book1.displayBook();
    book2.displayBook();
    book3.displayBook();

    
  }
}