class Argument {

public static void main(String[] args) {
for(String s: args) {
System.out.println(s);
}
}
}