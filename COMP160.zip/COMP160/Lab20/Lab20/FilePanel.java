/** FilePanel.java
  * Lab 20, COMP160,  2016
  * 
  * a JPanel which creates 2 instances of Rectangle objects, 
  * stores them in an array, and draws them 
  */

import java.awt.*;
import javax.swing.*;
import java.io.*;
import java.util.*;

public class FilePanel extends JPanel{
  private Rectangle[] drawObjects = new Rectangle [10];
  private int count;
  private Color colour;
  private boolean fill;
  
  
  /**constructor instantiates 6 Rectangle objects*/
  public FilePanel(){
    String fileName = "LongBadData.txt";
    try {
      Scanner fileScan = new Scanner (new File(fileName));
      while (fileScan.hasNextLine() && count < drawObjects.length) {
        String inputLine = fileScan.nextLine();
        
        if (inputLine.matches("\\d+ \\d+ \\d+ \\d+ \\d+ \\d+")) {
          Scanner inputScan = new Scanner(inputLine);
          int fills = inputScan.nextInt();
          int color = inputScan.nextInt();
          int x = inputScan.nextInt();
          int y = inputScan.nextInt();
          int width = inputScan.nextInt();
          int height = inputScan.nextInt();
          
          if(fills == 0) {
            fill = false; }
          else {
            fill = true; }
          
          if(color == 1) {
            colour = Color.red; }
          else if(color == 2) {
            colour = Color.blue; }
          else if(color == 3) {
            colour = Color.green; }
          
          System.out.println(fill);
          drawObjects[count] = new Rectangle(fill, colour, x, y, width, height);
          count++;
        }
      }
    } catch(FileNotFoundException e) {
      System.out.println("File not found. Check file name and location.");
      System.exit(1);
    }
    setPreferredSize(new Dimension(300,300));
    setBackground(Color.yellow);
  }
  /*drawObjects[count] = new Rectangle(true,Color.red, 0, 0,30,30);
   count++;
   drawObjects[count] = new Rectangle(false,Color.blue, 50, 50,30,30);
   count++;*/
  
  /**each Rectangle will draw itself*/
  public void paintComponent(Graphics g){
    super.paintComponent(g);
    for(int i = 0; i < count; i++){
      drawObjects[i].draw(g);
    } 
  }
}
