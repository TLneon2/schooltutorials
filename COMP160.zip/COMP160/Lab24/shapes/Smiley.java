/** Support class Smiley.java
  * Lab 23, COMP160,  2016
  * draws a smiley
  */

package shapes;
import java.awt.*;

public class Smiley extends Shape {
  
  /** New Smiley objects, unique constructor, uses parent's random method
    */
  public Smiley() {
    width = 30;
    height = 30;
    x = randomRange(0, 400 - width);
    y = randomRange(0, 400 - height);
    colour = new Color(randomRange(0,255), randomRange(0,255), randomRange(0,255));
    
    if (y >= 200) {
      moveY = -moveY;
      moveX = -moveX;    
    }
  }
    
    /** Draws Smiley objects and set colours via graphics
      */  
    public void display (Graphics g) {
      g.setColor(colour);
      g.fillOval(x+7,y+8,4,4);
      g.fillOval(x+20,y+8,4,4);
      g.drawArc(x+8, y+10, 15, 13, 190, 160);
  }
}