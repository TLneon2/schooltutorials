/** Application class ShapePanel.java
  * Lab 24, COMP160,  2016
  */

package shapes;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;

public class ShapePanel extends JPanel {
  private ArrayList<Shape> shapes = new ArrayList<Shape>();
  private DrawingPanel drawPanel;
  private JPanel controlPanel;
  private JTextField showNum;
  private JLabel countLabel;
  private int i;
  Timer timer, timer2;
  private final int DELAY = 10;
  private JButton[] buttons = {new JButton("Circle"), new JButton("Square"), new JButton ("Oval"), new JButton("Smiley"), new JButton("Swirl"),
    new JButton ("Start"), new JButton ("Stop"), new JButton("Remove")};
  private String index;
  
  /** Panel creates buttons, labels and sets actionlistener to addShape
    * It adds drawPanel and controlPanel
    * 2 timers are created for movement for circles
    * actionlistener is assigned to the timers as well
    * Panel adds 2 timers: timer (movement) and timer2 (enlarges)
    */  
  public ShapePanel() {
    
    controlPanel = new JPanel();
    showNum = new JTextField(2);
    countLabel = new JLabel();
    countLabel.setText("Remove Which?");
    
    ButtonListener bl = new ButtonListener();
    
    timer = new Timer(DELAY, bl);
    timer2 = new Timer(DELAY+6000, bl);
    
    for (JButton element: buttons) {
      element.addActionListener(bl);
      controlPanel.add(element);
    }
    
    controlPanel.setPreferredSize(new Dimension(100,400));
    controlPanel.add(showNum);
    controlPanel.add(countLabel);
    add(controlPanel);
    
    drawPanel = new DrawingPanel();
    add(drawPanel);
    
    setBackground(Color.yellow);
  }
  
  public static void main(String[] args) {
    JFrame frame = new JFrame();
    frame.getContentPane().add(new ShapePanel());
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.pack();
    frame.setVisible(true);
    frame.setTitle("Lab 24");
    
  }
  
  /** Inner class for DrawingPanel
    * paintComponent method displays shapes
    * as they are put into the array
    */  
  private class DrawingPanel extends JPanel {
    
    public DrawingPanel() {
      setPreferredSize(new Dimension(400,400));
      setBackground(Color.pink);
    }
    
    public void paintComponent(Graphics g){
      super.paintComponent(g);
      for(i = 0; i < shapes.size(); i++){
        shapes.get(i).display(g);
        shapes.get(i).showIndex(g,i);
      } 
    }
  }
  
  /** ActionListener inner class for button
    * It creates a new shape per button press
    * regardless of whether the button was pressed
    * count is incremented and displayed
    * 
    * When timer start button is pressed, 2 timers start
    * Each shape will use a support move method
    * 6000ms later, all shapes will be enlarged
    * 
    * Remove button deletes objects at a certain index
    */  
  private class ButtonListener implements ActionListener {
    
    public void actionPerformed(ActionEvent e) {      
      
      if(e.getSource() == timer) {
        for(Shape s: shapes) {
          s.move();
        }
      }
      
      else {
        JButton button = (JButton) e.getSource();
        
        if(button.getText().equals("Start")) {
          timer.start();    
        }
        else if(button.getText().equals("Stop")) {
          timer.stop(); 
        }
        else if(button.getText().equals("Circle")) {
          shapes.add(new Circle());
        }
        else if(button.getText().equals("Square")) {
          shapes.add(new Square());
        }
        else if(button.getText().equals("Oval")) {
          shapes.add(new Oval());
        }
        else if(button.getText().equals("Smiley")) {
          shapes.add(new Smiley());
        }
        else if(button.getText().equals("Swirl")) {
          shapes.add(new Swirl());
        }
        else if(button.getText().equals("Remove")) {
          try {
            int in = Integer.parseInt(showNum.getText());
            shapes.remove(in); }
          catch(NumberFormatException f) {
            System.out.println("error. Check number format."); }
          catch(IndexOutOfBoundsException f) {
            System.out.println("error. Out of bounds.");
          }
        }
      }
      index = Integer.toString(shapes.size() - 1);
      if (index.equals("-1")) {
        index = "0";
      }
      showNum.setText(index);
      drawPanel.repaint();
    }
  }
}