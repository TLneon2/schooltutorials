/** Support class Oval.java
  * Lab 23, COMP160,  2016
  */

package shapes;
import java.awt.*;

public class Oval extends Shape {
  
  /** New Oval objects, unique constructor, uses parent's random method
    */
  public Oval() {
    width = randomRange(10, 30);
    height = 4 * width;
    x = randomRange(0, 400 - width);
    y = randomRange(0, 400 - height);
    colour = new Color(randomRange(0,255), randomRange(0,255), randomRange(0,255));
    
    if (y >= 200) {
      moveY = -moveY;
      moveX = -moveX;    
    }
  }
    
    /** Draws fillOval objects and set colours via graphics
      */  
    public void display (Graphics g) {
      g.setColor(colour);
      g.fillOval(x,y,width,height);
  }
}