/** Support class Circle.java
  * Lab 24, COMP160,  2016
  */

package shapes;
import java.awt.*;

public class Circle extends Shape {
  
  /** Draws fillOval objects and set colours via graphics
    */  
  public void display (Graphics g) {
    g.setColor(colour);
    g.fillOval(x,y,width,height);
  }
}