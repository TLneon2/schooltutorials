/** Support class Square.java
  * Lab 23, COMP160,  2016
  * draws a square
  */

package shapes;
import java.awt.*;

public class Square extends Shape {
  
  /** Draws square objects and set colours via graphics
    */  
  public void display (Graphics g) {
    g.setColor(colour);
    g.fillRect(x,y,width,height);
  }
}