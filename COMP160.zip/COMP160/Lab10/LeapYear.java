/** Application class for LeapYear.java
  * Lab 10 COMP160
  * Theon Leong 
  */

class LeapYear {
  private int year;
  /** It evaluates five values to see if they are leap years
  */ 
  public static void main(String[]args){
    leapYear(2014);
    leapYear(2016);
    leapYear(1900);
    leapYear(2000);
    leapYear(1565);  
  }
 
  /** method to determine if it is a leap year using conditions
  */ 
  public static void leapYear(int year) {
    
    if (year % 4 == 0 && year >= 1582 ) {
      System.out.println(year + ": " + "is a leap year.");  
    }
    else if (year % 100 == 0 && year % 400 != 0) {
      System.out.println(year + ": " + "is a leap year.");
    }
    else if (year < 1582) {
      System.out.println(year + ": " + "predates the gregorian calendar.");
    }
    else {
      System.out.println(year + ": " + "is not a year year.");
    }
  }
}